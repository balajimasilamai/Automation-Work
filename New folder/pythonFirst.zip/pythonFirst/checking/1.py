# importing the modules
import time
import win32com.client
#import autoit
from selenium import webdriver
import csv
import pandas as pd
import re
from PIL import Image, ImageTk
#from HoverInfo import HoverInfo
from datetime import datetime
import datetime
#import sys
from tkinter import * 
from tkinter import messagebox
from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.common.keys import Keys
#from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
#from selenium.webdriver.chrome.options import Options
import xlwt
from threading import Thread
from tkinter import ttk
import pythoncom
import sqlite3
import xlrd as xl
import xlwt as xw
import xlrd
import smtplib
import mimetypes
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import datetime

class database():
    conn=sqlite3.connect('crq_status_database.db')
    cur=conn.cursor()
    def table_exists_or_not(self):
        global cur
        op=self.cur.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='crq_status'")
        print (op)
        for i,data in enumerate(op.fetchall()):
            print (i)
            print (data)
            if data[0]==1:
                print ('Table Alreay exists with some data')
                #op1=cur.execute("SELECT * from crq_status")       
                #for i1,data1 in enumerate(op1.fetchall()):
                #print (data1)
            else:
                self.cur.execute("""Create table if not exists crq_status (crq_number varchar2(50),
                                        Owner  varchar2(50),
                                        crq_status varchar2(50),
                                        task_status  varchar2(30),
                                        Approver_Group_Name varchar2(50),
                                        Approvers_Name varchar2(200),
                                        Approver_Sign varchar2(50),
                                        Approver_Alternate varchar2(50),
                                        Approval_date date)
                                       """)
            self.conn.commit()
    def data_exists_or_not(self):
                op1=self.cur.execute("SELECT count(*) from crq_status")       
                for i1,data1 in enumerate(op1.fetchall()):
                      if int(data1[0])>1:
                         print ('Data alreay exists and need to delete')
                         self.cur.execute('DELETE FROM crq_status')
                         self.conn.commit()
    def insert_into_database(self):
     global cur
     workbook=xl.open_workbook('CRQ Status.xls')
     sheet=workbook.sheet_by_index(0)
     total_rows=sheet.nrows
     total_cols=sheet.ncols

     for row in range(1,total_rows):
          for col in range(0,total_cols):
            if col==0:
               crq_number=sheet.cell_value(row,col)
               #print (crq_number)
            if col==1:
               Owner=sheet.cell_value(row,col)
               #print (Owner)
            if col==2:
               crq_status=sheet.cell_value(row,col)
               #print (crq_status)
            if col==3:
               task_status=sheet.cell_value(row,col)
               #print (task_status)
            if col==4:
               Approver_Group_Name=sheet.cell_value(row,col)
               #print (Approver_Group_Name)
            if col==5:
               Approvers_Name=sheet.cell_value(row,col)
               #print (Approvers_Name)
            if col==6:
               Approver_Sign=sheet.cell_value(row,col)
               #print (Approver_Sign)
            if col==7:
               Approver_Alternate=sheet.cell_value(row,col)
               #print (Approver_Alternate)
            if col==8:
               Approval_date=sheet.cell_value(row,col)
               #print (Approval_date)
          #cur.execute('insert into crq_status values ('+crq_number+','+Owner+','+crq_status+','+task_status+','+Approver_Group_Name+','+Approvers_Name+','+Approver_Sign+','+Approver_Alternate+','+Approval_date+')')
          self.cur.execute('insert into crq_status values (?,?,?,?,?,?,?,?,?)',(crq_number,Owner,crq_status,task_status,Approver_Group_Name,Approvers_Name,Approver_Sign,Approver_Alternate,Approval_date,))
          self.conn.commit()
               
    def writing_into_new_file(self):
     global cur
     columns=['CRQ Number','Owner','CRQ Status','Task Status','Approver Group Name','Approvers Name','Approver Sign','Approver Alternate','Approval date']
     style = xw.easyxf('pattern: pattern solid, fore_colour light_blue;'
                              'font: colour white, bold True;'
                    'borders: top_color black, bottom_color black, right_color black, left_color black,\
                              left thin, right thin, top thick, bottom thin;')
     new_file_name='crq_status_new.xls'
     wb = xw.Workbook()
     ws = wb.add_sheet('Crq_status_new',cell_overwrite_ok=True)
     column=0
     for i in columns:
            ws.write(0,column,i,style)
            column+=1
     ws.col(0).width =256 * 20
     ws.col(1).width =256 * 35
     ws.col(2).width =256 * 30
     ws.col(3).width =256 * 15
     ws.col(4).width =256 * 20
     ws.col(5).width =256 * 70
     ws.col(6).width =256 * 70
     ws.col(7).width =256 * 70
     ws.col(8).width =256 * 70



     #To get the total number of task for the each CRQ
     output=self.cur.execute("""select  crq_number,count(*) from crq_status   group by crq_number """)
     row=1
     for crq_num,count in output.fetchall():
         # if the CRQ has more than one task this block will execute
          if count>1:
           #To get the count of Approver_Group_Name
           output1=self.cur.execute('select  Approver_Group_Name,count(*) from crq_status where crq_number=? group by Approver_Group_Name ',(crq_num,))
           for Approver_Group_Name,count1 in output1.fetchall():
             #if the Approver_Group_Name duplicates this block will execute
             if count1>1:
                #To get the distinct task status of the Approver_Group_Name
                output2=self.cur.execute('select  count(distinct(task_status)) from crq_status where crq_number=? and Approver_Group_Name=?',(crq_num,Approver_Group_Name,))
                for distinct_count in output2.fetchall():
                   #If the  distinct task status is equal to 1
                   if distinct_count[0]==1:
                      output3=self.cur.execute('select  * from crq_status where crq_number=? and Approver_Group_Name=? and Approval_date=(select max(Approval_date) from crq_status where crq_number=? and Approver_Group_Name=? )',(crq_num,Approver_Group_Name,crq_num,Approver_Group_Name))
                      for data in output3.fetchall():
                         #print ('For same task_status')
                         #print (data)
                         #print (len(data))
                         for col in range(0,len(data)):
                            ws.write(row,col,str(data[col]))
                         row=row+1
                   #If the  distinct task status greater than 1
                   if distinct_count[0]>1:
                      output4=self.cur.execute("select  * from crq_status where crq_number=? and Approver_Group_Name=?  and Approval_date=''",(crq_num,Approver_Group_Name,))
                      #print ('Finding Pending status')
                      for data in output4.fetchall():
                         #print ('For different task_status')
                         #print (data)
                         for col in range(0,len(data)):
                            ws.write(row,col,str(data[col]))
                         row=row+1
             if count1==1:
                #If te count1 ==1 then it has only one 
                output5=self.cur.execute('select * from crq_status where crq_number=? and Approver_Group_Name=?',(crq_num,Approver_Group_Name))
                for data in output5.fetchall():
                   #print ('No duplicate exists ')
                   #print (data)
                   for col in range(0,len(data)):
                         ws.write(row,col,str(data[col]))
                   row=row+1
               
          print ('################################################################')
          if count==1:
             output6=self.cur.execute('select  * from crq_status where crq_number=? group by Approver_Group_Name ',(crq_num,))
             for data in output6.fetchall():
                 #print ('It consists of only one entry')
                 #print (data)
                 for col in range(0,len(data)):
                    ws.write(row,col,str(data[col]))
                 row=row+1
     wb.save(new_file_name)

#==================== send mail with html class ================

class send_mail_with_html():

    def get_friday_date(self):
         today = datetime.date.today()
         friday = today + datetime.timedelta( (4-today.weekday()) % 7 )
         print (friday)

         date_list=str(friday).split('-')

         print (date_list)

         friday_date=date_list[1]+'/'+date_list[2]+'/'+date_list[0]

         print ('friday_date ',friday_date)
         return friday_date

    def send_mail(self,date):
         friday_date=date
         emailfrom ="DL-windstream_metasolv@prodapt.com"
         emailto = 'balaji.ma@prodapt.com'
         #emailto ='annamalai.d@prodapt.com'
         #emailfrom = 'balaji.ma@prodapt.com'
         #emailto = 'DL-windstream_metasolv@prodapt.com'
         #fileToSend = filename
         #date='11/9/2018'
         msg = MIMEMultipart()
         msg["From"] = emailfrom
         msg["To"] = emailto
         msg["Subject"] = "CRQ Scheduled on " + friday_date 
         msg.preamble = "CRQ Report"

         book=xlrd.open_workbook('crq_status_new.xls')
         sheet=book.sheet_by_index(0)
         print (sheet.nrows)
         total_rows=sheet.nrows
         total_cols=sheet.ncols
         rownum1=[]
         """for i in range(1,total_rows):
             if sheet.cell_value(i,0) != '':
                 print (i)
                 rownum1.append(i)"""
         for i in range(1,total_rows):
              if sheet.cell_value(i,0) != sheet.cell_value(i-1,0):
                  print (i)
                  rownum1.append(i)
         print (rownum1)

         html="""
         <html>
         <head>
         <style>
           * { 
             margin: 0; 
             padding: 0; 
           }
           body { 
            font-family: Calibri, Candara, Segoe, "Segoe UI", Optima, Arial, sans-serif;
         font-size: 16px;
         font-style: normal;
         font-variant: normal;
         font-weight: 400;
         line-height: 20px; 
           }
           .top {
           border-top: 2px solid black;
           border-color: black;
         }
         .bottom {
           border-bottom: 2px solid black;
           border-color: black;
         }
         .left {
           border-left: 2px solid black;
           border-color: black;
         }
         .right {
           border-right: 2px solid black;
           border-color: black;
         }
           table { 
              border: 2px solid black;
             width: Auto; 
             border-collapse: collapse; 
           }
           tr:nth-of-type(odd) { 
             background: #eee; 
           }
           tr:nth-of-type(even) { 
             background: #fff; 
         }
           th { 
         background: #333; 
         color: white; 
         font-weight: bold; 
         text-align: center; 
         padding: 6px; 
         border: 1px solid #9B9B9B; 
           }
           td { 
             padding: 6px; 
             border: 1px solid #9B9B9B; 
             text-align: center; 
           }
         p {
              font-family: Calibri, Candara, Segoe, "Segoe UI", Optima, Arial, sans-serif;
         font-size: 16px;
         font-style: normal;
         font-variant: normal;
         font-weight: 400;
         line-height: 20px;
         }
         </style>
         </head>
         <body>
         <p>
         Hi All ,
         <br />
         <br />
         Please find the CRQ Status Report for date """+ friday_date + """
         <br />
         <br />
         </p>
         <table border='1'>
         <tr>
         <th>CRQ</th>
         <th>Owner</th>
         <th>Status</th>
         <th>Approver Status</th>
         <th>Approver Group Name</th>
         <th>Approver Names</th></tr>"""

         #rownum1=[1,4,8,14,15,18]
         print(len(rownum1))
         for i in range(0,len(rownum1),1) :
             try:
                 diff=rownum1[i+1]-rownum1[i]
                 start=rownum1[i]
                 end=rownum1[i+1]
             except :
                 diff=(total_rows)-rownum1[i]
                 start=rownum1[i]
                 end=total_rows
            
             html=html+'<tr >' +"<td rowspan="+str(diff)+">"+sheet.cell_value(rownum1[i],0)+'</td>' +"<td rowspan="+str(diff)+">"+sheet.cell_value(rownum1[i],1)+'</td>' +"<td rowspan="+str(diff)+">"+sheet.cell_value(rownum1[i],2)+'</td>'
             if diff > 1:
                             for r in range(start,end,1):
                                    for col in range(3,6,1):
                                        if sheet.cell_value(r,col)== 'Pending':
                                            html=html+'<td style = "color:Orange">'+str(sheet.cell_value(r,col))+'</td>'
                                        elif sheet.cell_value(r,col)== 'Approved':
                                            html=html+'<td style = "color:Green">'+str(sheet.cell_value(r,col))+'</td>'
                                        elif sheet.cell_value(r,col)== 'Rejected':
                                            html=html+'<td style = "color:Red">'+str(sheet.cell_value(r,col))+'</td>'
                                        else:
                                            html=html+'<td HEIGHT=20">'+str(sheet.cell_value(r,col))+'</td>'
                                            tr_var=1
                                    html = html + "</tr>"
             else:
                 for col in range(3,6,1):
                     html=html+'<td HEIGHT=20></td>'
                 html = html + "</tr>"

         html = html + "</table></body></html>"

         #print (html)
                    
                
         part2 = MIMEText(html, 'html')
         msg.attach(part2)
         server = smtplib.SMTP("outlook.prodapt.com:587")
         server.connect('outlook.prodapt.com')
         print (part2)
         server.sendmail(emailfrom, emailto, msg.as_string())
         server.quit()


#=============Checking the VPN connectivity =========
def check_vpn_status():
    import subprocess
    import time

    host = '10.108.109.194'
    ping = subprocess.Popen(["ping.exe","-n","1","-w","1",host],stdout = subprocess.PIPE).communicate()[0]
    time.sleep(2)
    if ('unreachable' in str(ping)) or ('timed' in str(ping)) or ('failure' in str(ping)):
        ping_chk = 0
    else:
        ping_chk = 1
        
    if ping_chk == 1:
         open_browser()
    else:
       messagebox.showinfo('Warning','VPN is not connected')



#========== OPen the sheet to get the CRQ number=====================================================

# ==== Openening a browser ==========
def open_browser():
    db=database()
    db.table_exists_or_not()
    db.table_exists_or_not()
    db.data_exists_or_not()
    db.insert_into_database()
    db.writing_into_new_file()
    mail=send_mail_with_html()
    date=mail.get_friday_date()
    mail.send_mail(date)
  
#check_vpn_status()

open_browser()




